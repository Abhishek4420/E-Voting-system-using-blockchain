var Contest = artifacts.require("./Contest.sol");

module.exports = function(deployer) {
  deployer.deploy(Contest)
};
